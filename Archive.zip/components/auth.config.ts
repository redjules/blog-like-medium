export default {
  providers: [
    {
      domain: "https://tender-sole-27.clerk.accounts.dev",
      applicationID: "convex",
    },
  ],
};
