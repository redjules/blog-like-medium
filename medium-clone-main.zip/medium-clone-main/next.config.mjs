/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['robust-gerbil-129.convex.cloud']
  }
}

export default nextConfig
