export default {
  providers: [
    {
      domain: 'https://full-elk-50.clerk.accounts.dev',
      applicationID: 'convex'
    }
  ]
}
